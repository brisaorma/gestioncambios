# Gestión de cambios

Formulario para clientes (Paso 1 y Paso 2) y vista de tienda.

- **Frontend:** un solo archivo `index.html`, publicado con GitHub Pages.
- **Datos ("el Excel"):** Google Sheet conectado por Google Apps Script (`API_URL` dentro de `index.html`). No se migra: sigue igual.
- **Exportar a Excel:** botón en la vista Tienda, genera `cambios.xlsx` en el navegador.

## Publicar
Settings → Pages → Deploy from a branch → `main` / `(root)` → Save.
